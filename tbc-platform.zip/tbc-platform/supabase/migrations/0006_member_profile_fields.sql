-- Adds fields for the richer member directory: discipline (e.g. "Computer
-- Engineering", "Mechanical Engineering") and hobbies/interests as a list.

alter table members add column if not exists discipline text;
alter table members add column if not exists hobbies text[];
