-- Tightens roles visibility: previously anyone with the public anon key could
-- query the roles table directly even though the /roles page is now gated
-- behind login in the UI. This makes the database enforce the same rule.

drop policy if exists "roles are publicly readable" on roles;

create policy "only logged-in members can read roles" on roles
  for select using (auth.uid() is not null);
