-- 0003 only required auth.uid() is not null (any logged-in user, including
-- pending). This tightens it to match the new RequireActiveMember guard:
-- only approved (status='active') members can read roles.

drop policy if exists "only logged-in members can read roles" on roles;

create policy "only active members can read roles" on roles
  for select using (
    exists (select 1 from members where auth_user_id = auth.uid() and status = 'active')
    or is_admin()
  );
