-- Auto-creates a `members` row whenever someone signs up via Supabase Auth.
-- New members start as status='pending' with no role — an admin flips them
-- to 'active' and assigns a role_id manually (Table Editor for now).

create or replace function generate_member_id() returns text as $$
  select 'TBC-' || to_char(now(), 'YYYY') || '-' || lpad(floor(random() * 10000)::text, 4, '0');
$$ language sql volatile;

create or replace function handle_new_auth_user() returns trigger as $$
begin
  insert into members (auth_user_id, member_id, full_name, status)
  values (
    new.id,
    generate_member_id(),
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    'pending'
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_auth_user();
