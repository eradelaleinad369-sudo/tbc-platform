-- Fixes 0004: triggers on auth.users don't reliably inherit the 'public'
-- search_path, so unqualified table/function names inside the trigger can
-- fail silently and roll back the entire signup. This re-defines both
-- functions with explicit public.* references and a pinned search_path.

create or replace function public.generate_member_id() returns text as $$
  select 'TBC-' || to_char(now(), 'YYYY') || '-' || lpad(floor(random() * 10000)::text, 4, '0');
$$ language sql volatile set search_path = public;

create or replace function public.handle_new_auth_user() returns trigger as $$
begin
  insert into public.members (auth_user_id, member_id, full_name, status)
  values (
    new.id,
    public.generate_member_id(),
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    'pending'
  );
  return new;
end;
$$ language plpgsql security definer set search_path = public;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_auth_user();
